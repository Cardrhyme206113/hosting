// Keys to disable/enable effects: F5 - Bloom, F6 - Lens Flares, F7 - AO and GI, F8 - Depth of Field, F9 to view AO/GI buffer.
#define GREAT_FX_AO_ENABLE_GI 1 // Enables Indirect Illumination
#define GREAT_FX_AO_DO_ADDITIONAL_SAMPLES 0 //Not recomended, but should improve quality a bit.
#define GREAT_FX_AO_OFFSETS_TYPE 2 //0 - ssao, 1 - hbao(better, can be faster, didn't checked yet), 2 - best and beast(preformance eater).
#define GREAT_FX_AO_OUTPUT_FACTOR_TYPE 1
#define GREAT_FX_DOF_AUTOFOCUS_TYPE 1 // 1 - simple center focus, 2 - average from each screen corner and center, 3 - average from 6-bladed aperture
#define GREAT_FX_ENABLE_BLOOM 1
#define GREAT_FX_ENABLE_LF 1
#define GREAT_FX_ENABLE_DOF 1
#define GREAT_FX_ENABLE_AO 1
#define GREAT_FX_ENABLE_TONEMAP 1
// Global Lens parameters.
uniform float fAperture = 8.5f;
uniform float fApertureDiameter = 1.16f;
uniform float fFocalLength = 4.5f;
// Bloom parameters.
uniform float fBloomBrightPassValue = 0.5f;
uniform float fBloomMultiplierValue = 0.4f;
// DoF parameters.
static int DoFSamplesPerRing = 4;
static int DoFRings = 5;
static int BokehDoFEdgeCount = 5;
static int BokehDoFSamplePerEdge = 2;
uniform float DoFMaxBlur = 2f;
uniform float BokehDoFIntensity = 1f;
uniform float BokehDoFTreshold = 0.7f;
// AO and GI parameters.
uniform float fAORadius = 1.5f;
uniform float fAOBias = 0.0f;
uniform float fDepthClip = 90f;
uniform float fGIRadius = 6.0f;
uniform float fBlurSize = 1.0f;
uniform float fAttenuation = 8.0f;
uniform float fGI_Intensity = 8.0f;
uniform float fAdditionalSamplesShift = 5.0f;
uniform float fAOBlurDepthTreshold = 0.001f;
uniform float fAODepthBias = 0.01f;
static const float fAOTexScale = 0.25f;
static int g_NumDir = 8;
static int g_NumRays = 8;
static int g_NumSteps = 8;
static int g_BlurSamples = 16;